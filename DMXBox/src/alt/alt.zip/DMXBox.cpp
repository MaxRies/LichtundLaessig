/*
 * Autor: Simon Fritz
 *
 * Channel-table:
 * 1-3 = Smoking-Machine
 *      1 = heater
 *      2 = pumping capacity
 *      3 = external devices like Fans (if present)
 *      https://wiki.dmxcontrol.de/wiki/DMX-Nebelmaschine
 * 4- =
 */
#include "DMXBox.h"

byte SMOKING_PREHEAT[] = {255, 0, 0};
byte SMOKING_SMOKE[] = {255, 255, 0};
byte SMOKING_SMOKE_AND_BLOW[] = {255, 255, 255};

DMXBox::DMXBox(PubSubClient client)
  : Device ("DMXBox"){
    this->_client = client;
}

///////////////// Smoking-Machine /////////////////

void DMXBox::Smoking_start_preHeat(){
  Smoking_is_heating = true;
  Smoking_is_smoking = false;
}

void DMXBox::Smoking_start_cooldown(){
  Smoking_is_smoking = false;
  Smoking_is_heating = false;
  Smoking_is_blowing = false;
}

void DMXBox::Smoking_start_smoking(){
  Smoking_is_heating = true;
  Smoking_is_smoking = true;
}

void DMXBox::Smoking_start_smoking(int ms, bool blow){
  this->_SmokingStartTime = millis();
  this->_SmokingEndTime = _SmokingStartTime + ms;
  Smoking_is_smoking = true;
  if(blow)
  {
    Smoking_is_blowing = true;
  }
}

void DMXBox::Smoking_start_blowing(){
  Smoking_is_blowing = true;
}

void DMXBox::Smoking_stop_smoking(){
  Smoking_is_smoking = false;
}

void DMXBox::Smoking_preheat(){
  dmxA.setChans(SMOKING_PREHEAT, 3, 1);
}

void DMXBox::Smoking_smoke(){
  dmxA.setChans(SMOKING_SMOKE, 3, 1);
}

void DMXBox::Smoking_smoke_and_blow(){
  dmxA.setChans(SMOKING_SMOKE_AND_BLOW, 3, 1);
}

///////////////// Other-DMX-Device /////////////////



///////////////// loop /////////////////

void DMXBox::loop(){
  if(Smoking_is_smoking) // if smoking heat as well!
  {
    digitalWrite(DMX_STATUS_PIN, HIGH);
    if(Smoking_is_blowing)
    {
      Smoking_smoke_and_blow();
    }
    else
    {
      Smoking_smoke();
    }
  }
  else if(Smoking_is_heating) // if only heating preheat the smoking machine
  {
    digitalWrite(DMX_STATUS_PIN, HIGH);
    Smoking_preheat();
  }
  else
  {
    digitalWrite(DMX_STATUS_PIN, LOW);
  }
}


void DMXBox::setup(){
  dmxA.begin(12);
  pinMode(DMX_STATUS_PIN, OUTPUT);
}

bool DMXBox::subscribe_to_topics(){
  bool error = false;
  char c_number[4];
  int num = _number;
  snprintf(c_number, 4, "%d", num);
  char topicBuffer[200] = "devices/Nebelmaschine/";
  strcat(topicBuffer, c_number);
  strcat(topicBuffer, "/#");
  #ifdef debug
  Serial.print("Subscribed to: ");
  Serial.println(topicBuffer);
  #endif
  return _client.subscribe(topicBuffer);
}
