/*
 * Autor: Simon Fritz
 *
 * Channel-table:
 * 1-3 = Foggingmachine
 *      1 = heater
 *      2 = pumping capacity
 *      3 = external devices like Fans (if present)
 *      https://wiki.dmxcontrol.de/wiki/DMX-Nebelmaschine
 * 4- =
 */

#ifndef DMXBox_h
#define DMXBox_h
#include <device.h>
#include <PubSubClient.h>
#include "espDMX.H"

#define DMX_STATUS_PIN 2

class DMXBox : public Device
{
private:
  unsigned int _SmokingStartTime; // in ms
  unsigned int _SmokingEndTime;  // in ms
  bool Smoking_is_heating = false;
  bool Smoking_is_smoking = false;
  bool Smoking_is_blowing = false;
  PubSubClient _client;
public:
  DMXBox(PubSubClient client);
  void Smoking_start_preHeat();
  void Smoking_start_cooldown();
  void Smoking_start_smoking();
  void Smoking_start_smoking(int ms, bool blow);
  void Smoking_start_blowing();
  void Smoking_stop_smoking();
  void Smoking_preheat();
  void Smoking_smoke();
  void Smoking_smoke_and_blow();
  void loop();
  void setup();
  bool subscribe_to_topics();
};

#endif
