#ifndef Strobo_h
#define Strobo_h
#define FASTLED_ESP8266_RAW_PIN_ORDER
#include "device.h"
#include <PubSubClient.h>
#include <FastLED.h>
#include <Servo.h>
#define SERVO12 D6
#define SERVO34 D7
#define LED_R D3
#define LED_G D2
#define LED_B D1
#define LED_PIN_1 D4
#define LED_PIN_2 D5

#define NUM_LED_OUT 160
#define NUM_LED_OBEN 80
#define NUM_LED_UNTEN 80
#define NUM_LEDS_ON_PIN_1 80
#define NUM_LEDS_ON_PIN_2 80

struct Line{
  int pos;
  int width;
  CRGB fg;  // Linienfarbe
  CRGB bg;  // Hintergrundfarbe

  Line(CRGB foreground, CRGB background, int width) {
    pos = 1;
    width = width;
    fg = foreground;
    bg = background;
  }
};


class Strobo : public Device
{
private:
  PubSubClient _client;
public:
  Strobo(PubSubClient client);
  void setup();
  void loop();

  bool subscribe_to_topics();
};

void light(bool on);
void login_light(int color);
void set_pattern_mode(int mode);
void set_pattern_color(int color);
void strobo(bool on);
void set_strobo_color(int color);
int line_check(int num_led);
void fadeToColor(CRGB *LEDs, int numLEDs, CRGB color2, int divisor);
void led100(int color);
void pattern_led100strobo(int color, int duration);
void pattern_line(bool forward, bool inverse, int count, int duration);
void pattern_line_stereo(bool forward, bool inverse, bool endless, int duration);
void pattern_line_stereo_explosion(bool forward, bool inverse, bool endless, int duration, int explosionColor);
void pattern_asiaBlink(bool forward, int duration);
void pattern_asiaBlink_flash(bool forward, int duration);
void pattern_explosion(int duration);
void pulse(CHSV color, int interval);
void random_stars(int chance);
void convert();
CRGB colors(int color);

#endif
